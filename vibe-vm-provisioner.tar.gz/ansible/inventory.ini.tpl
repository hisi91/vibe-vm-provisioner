# =============================================================================
# ansible/inventory.ini.tpl — Template d'inventaire Ansible
# Généré automatiquement par `make deploy` via envsubst → ansible/inventory.ini
# Ne pas éditer inventory.ini directement (il est dans .gitignore)
# =============================================================================

[vibe_vm]
${TARGET_IP} ansible_user=${TARGET_USER} ansible_ssh_private_key_file=${SSH_KEY_PATH} ansible_ssh_common_args='-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null'

[vibe_vm:vars]
ansible_python_interpreter=/usr/bin/python3
